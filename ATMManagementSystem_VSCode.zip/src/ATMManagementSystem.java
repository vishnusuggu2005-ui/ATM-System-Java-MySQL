import java.math.BigDecimal;
import java.sql.*;
import java.util.Scanner;

public class ATMManagementSystem {
    private static final Scanner sc = new Scanner(System.in);
    private static final String DB_URL = "jdbc:mysql://localhost:3306/atm_db";
    private static final String DB_USER = "root";
    // Change this to your local MySQL password.
    private static final String DB_PASSWORD = "YOUR_MYSQL_PASSWORD";

    public static void main(String[] args) {
        System.out.println("================================");
        System.out.println("       ATM MANAGEMENT SYSTEM");
        System.out.println("================================");

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            System.out.println("Database connected successfully.");

            while (true) {
                System.out.println("\n1. Login");
                System.out.println("2. Exit");
                int choice = readInt("Choose an option: ");

                if (choice == 1) {
                    Account account = login(connection);
                    if (account != null) {
                        showAtmMenu(connection, account);
                    }
                } else if (choice == 2) {
                    System.out.println("Thank you for using the ATM.");
                    break;
                } else {
                    System.out.println("Invalid option. Try again.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Could not connect to MySQL.");
            System.out.println("Check that MySQL is running, the database exists, and DB_URL/DB_USER/DB_PASSWORD are correct.");
            System.out.println("Details: " + e.getMessage());
        }
    }

    private static Account login(Connection con) throws SQLException {
        System.out.print("Enter account number: ");
        String accountNumber = sc.nextLine().trim();
        System.out.print("Enter 4-digit PIN: ");
        String pin = sc.nextLine().trim();

        String sql = "SELECT account_number, holder_name, balance FROM accounts WHERE account_number = ? AND pin = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, accountNumber);
            ps.setString(2, pin);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    System.out.println("\nWelcome, " + rs.getString("holder_name") + "!");
                    return new Account(rs.getString("account_number"),
                            rs.getString("holder_name"), rs.getBigDecimal("balance"));
                }
            }
        }
        System.out.println("Invalid account number or PIN.");
        return null;
    }

    private static void showAtmMenu(Connection con, Account account) throws SQLException {
        boolean loggedIn = true;
        while (loggedIn) {
            System.out.println("\n========== ATM MENU ==========");
            System.out.println("1. Check balance");
            System.out.println("2. Deposit money");
            System.out.println("3. Withdraw money");
            System.out.println("4. Transaction history");
            System.out.println("5. Change PIN");
            System.out.println("6. Logout");
            int choice = readInt("Choose an option: ");

            switch (choice) {
                case 1 -> checkBalance(con, account.accountNumber);
                case 2 -> deposit(con, account.accountNumber);
                case 3 -> withdraw(con, account.accountNumber);
                case 4 -> transactionHistory(con, account.accountNumber);
                case 5 -> changePin(con, account.accountNumber);
                case 6 -> {
                    System.out.println("Logged out successfully.");
                    loggedIn = false;
                }
                default -> System.out.println("Invalid option. Try again.");
            }
        }
    }

    private static void checkBalance(Connection con, String accountNumber) throws SQLException {
        String sql = "SELECT balance FROM accounts WHERE account_number = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, accountNumber);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    System.out.println("Available balance: ₹" + rs.getBigDecimal("balance"));
                }
            }
        }
    }

    private static void deposit(Connection con, String accountNumber) throws SQLException {
        BigDecimal amount = readAmount("Enter deposit amount: ");
        if (amount == null) return;

        con.setAutoCommit(false);
        try {
            updateBalance(con, accountNumber, amount);
            addTransaction(con, accountNumber, "DEPOSIT", amount);
            con.commit();
            System.out.println("Deposit successful.");
            checkBalance(con, accountNumber);
        } catch (SQLException e) {
            con.rollback();
            throw e;
        } finally {
            con.setAutoCommit(true);
        }
    }

    private static void withdraw(Connection con, String accountNumber) throws SQLException {
        BigDecimal amount = readAmount("Enter withdrawal amount: ");
        if (amount == null) return;

        con.setAutoCommit(false);
        try {
            BigDecimal balance;
            String lockSql = "SELECT balance FROM accounts WHERE account_number = ? FOR UPDATE";
            try (PreparedStatement ps = con.prepareStatement(lockSql)) {
                ps.setString(1, accountNumber);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) {
                        con.rollback();
                        System.out.println("Account not found.");
                        return;
                    }
                    balance = rs.getBigDecimal("balance");
                }
            }

            if (balance.compareTo(amount) < 0) {
                con.rollback();
                System.out.println("Insufficient balance.");
                return;
            }

            updateBalance(con, accountNumber, amount.negate());
            addTransaction(con, accountNumber, "WITHDRAWAL", amount);
            con.commit();
            System.out.println("Please collect your cash. Withdrawal successful.");
            checkBalance(con, accountNumber);
        } catch (SQLException e) {
            con.rollback();
            throw e;
        } finally {
            con.setAutoCommit(true);
        }
    }

    private static void updateBalance(Connection con, String accountNumber, BigDecimal change) throws SQLException {
        String sql = "UPDATE accounts SET balance = balance + ? WHERE account_number = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setBigDecimal(1, change);
            ps.setString(2, accountNumber);
            if (ps.executeUpdate() != 1) {
                throw new SQLException("Account balance could not be updated.");
            }
        }
    }

    private static void addTransaction(Connection con, String accountNumber, String type, BigDecimal amount)
            throws SQLException {
        String sql = "INSERT INTO transactions (account_number, transaction_type, amount) VALUES (?, ?, ?)";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, accountNumber);
            ps.setString(2, type);
            ps.setBigDecimal(3, amount);
            ps.executeUpdate();
        }
    }

    private static void transactionHistory(Connection con, String accountNumber) throws SQLException {
        String sql = "SELECT transaction_type, amount, transaction_time FROM transactions " +
                     "WHERE account_number = ? ORDER BY transaction_time DESC LIMIT 20";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, accountNumber);
            try (ResultSet rs = ps.executeQuery()) {
                System.out.println("\n------ LAST 20 TRANSACTIONS ------");
                boolean found = false;
                while (rs.next()) {
                    found = true;
                    System.out.printf("%s | ₹%s | %s%n",
                            rs.getString("transaction_type"),
                            rs.getBigDecimal("amount"),
                            rs.getTimestamp("transaction_time"));
                }
                if (!found) System.out.println("No transactions found.");
            }
        }
    }

    private static void changePin(Connection con, String accountNumber) throws SQLException {
        System.out.print("Enter current PIN: ");
        String currentPin = sc.nextLine().trim();
        System.out.print("Enter new 4-digit PIN: ");
        String newPin = sc.nextLine().trim();

        if (!newPin.matches("\\d{4}")) {
            System.out.println("PIN must contain exactly 4 digits.");
            return;
        }

        String sql = "UPDATE accounts SET pin = ? WHERE account_number = ? AND pin = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, newPin);
            ps.setString(2, accountNumber);
            ps.setString(3, currentPin);
            if (ps.executeUpdate() == 1) {
                System.out.println("PIN changed successfully.");
            } else {
                System.out.println("Incorrect current PIN.");
            }
        }
    }

    private static BigDecimal readAmount(String prompt) {
        System.out.print(prompt);
        String input = sc.nextLine().trim();
        try {
            BigDecimal amount = new BigDecimal(input);
            if (amount.compareTo(BigDecimal.ZERO) <= 0 || amount.scale() > 2) {
                System.out.println("Enter a positive amount with at most 2 decimal places.");
                return null;
            }
            return amount;
        } catch (NumberFormatException e) {
            System.out.println("Invalid amount.");
            return null;
        }
    }

    private static int readInt(String prompt) {
        System.out.print(prompt);
        try {
            return Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private static class Account {
        private final String accountNumber;
        @SuppressWarnings("unused")
        private final String holderName;
        @SuppressWarnings("unused")
        private final BigDecimal balance;

        private Account(String accountNumber, String holderName, BigDecimal balance) {
            this.accountNumber = accountNumber;
            this.holderName = holderName;
            this.balance = balance;
        }
    }
}
