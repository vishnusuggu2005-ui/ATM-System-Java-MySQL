# ATM Management System (Java + MySQL)

A console-based ATM mini-project for learning Java, JDBC, SQL, and database transactions.

## Features
- Account login with account number and PIN
- Balance inquiry
- Deposit and withdrawal
- Transaction history (latest 20 transactions)
- Change PIN
- JDBC prepared statements and SQL transactions

## Requirements
- JDK 17 or newer
- MySQL Server 8.x
- VS Code with the **Extension Pack for Java**
- MySQL Connector/J JDBC driver

## 1. Create the database
1. Open MySQL Workbench or the MySQL command line.
2. Run the complete script in `database/atm_db.sql`.
3. Demo login:
   - Account number: `1001001`
   - PIN: `1234`

## 2. Set your MySQL password
Open `src/ATMManagementSystem.java` and change:
```java
private static final String DB_PASSWORD = "YOUR_MYSQL_PASSWORD";
```
Set it to your local MySQL password. Do not commit passwords to GitHub.

## 3. Add the MySQL JDBC driver
Download MySQL Connector/J from the official MySQL website:
https://dev.mysql.com/downloads/connector/j/

Create a `lib` folder in the project and put the downloaded `.jar` file inside it. In VS Code, make sure the Java project references the JAR. One easy approach is to open the project folder, install **Extension Pack for Java**, then use the Java Projects view to add the JAR to Referenced Libraries.

## 4. Run in VS Code
1. Open the `ATMManagementSystem` folder in VS Code.
2. Ensure the MySQL service is running.
3. Add the Connector/J JAR as described above.
4. Open `src/ATMManagementSystem.java`.
5. Click **Run** above `main`, or use the Java Projects view.

If you use a terminal, compile/run commands depend on your JAR filename and operating system. Example on Windows PowerShell, after placing the driver in `lib`:
```powershell
javac -cp "lib\mysql-connector-j-9.x.x.jar" -d out src\ATMManagementSystem.java
java -cp "out;lib\mysql-connector-j-9.x.x.jar" ATMManagementSystem
```
Replace `mysql-connector-j-9.x.x.jar` with the exact filename you downloaded.

## Important security note
This is an educational demo, not a production banking application. It stores demo PINs as plain text and has no encryption, lockout policy, audit controls, or real cash dispenser integration. Never use real banking credentials or real customer data. For a production design, store salted PIN hashes and implement strong authentication, rate limiting, secure secret management, and audited transaction controls.
